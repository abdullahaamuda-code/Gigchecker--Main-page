const siteInput = document.getElementById("site");
const checkBtn = document.getElementById("check");
const modalOverlay = document.getElementById("modalOverlay");
const closeModal = document.getElementById("closeModal");
const resultDiv = document.getElementById("result");
const shareIcon = document.getElementById("shareIcon");
const modeRadios = document.getElementsByName("mode");

// Enable manual input if user selects manual mode
modeRadios.forEach(radio => {
  radio.addEventListener("change", () => {
    if (radio.value === "manual" && radio.checked) {
      siteInput.disabled = false;
    } else if (radio.value === "current" && radio.checked) {
      siteInput.disabled = true;
    }
  });
});

// Main check function
checkBtn.addEventListener("click", async () => {
  let site = siteInput.value.trim();

  if (modeRadios[0].checked) {
    // Use current tab (Chrome extension API)
    try {
      let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = new URL(tab.url);
      site = url.hostname;
    } catch (err) {
      alert("Could not get current tab URL.");
      return;
    }
  }

  if (!site) {
    alert("Enter a site to check!");
    return;
  }

  resultDiv.innerHTML = "Loading...";
  modalOverlay.classList.add("active");

  // Domain age fetch
  let domainAge = "Unknown", createdDate = "Unknown";
  try {
    const rdapRes = await fetch("https://rdap.org/domain/" + site);
    if (rdapRes.ok) {
      const data = await rdapRes.json();
      const events = data.events || [];
      const regEvent = events.find(e => e.eventAction?.toLowerCase() === "registration");
      if (regEvent) {
        const created = new Date(regEvent.eventDate);
        const days = Math.floor((new Date() - created)/86400000);
        domainAge = days + " days";
        createdDate = created.toDateString();
      }
    }
  } catch(e){}

  // HTTPS check
  let connection = "Unknown";
  try { connection = new URL("https://" + site).protocol === "https:" ? "Secure" : "Not secure"; } 
  catch(e){ connection="Not secure"; }

  // Mock signals
  const nairaland = Math.floor(Math.random()*5);
  const reddit = Math.floor(Math.random()*5);
  const trustpilot = Math.floor(Math.random()*500);

  const positives = [];
  const risks = [];

  if(domainAge !== "Unknown" && parseInt(domainAge) > 365) positives.push("Domain is older than 1 year");
  if(connection === "Secure") positives.push("Uses HTTPS connection");
  if(trustpilot > 50) positives.push("Good number of Trustpilot reviews");

  if(domainAge === "Unknown" || parseInt(domainAge) < 90) risks.push("New or unknown domain");
  if(connection !== "Secure") risks.push("No HTTPS / insecure connection");
  if(trustpilot < 5) risks.push("Very few Trustpilot reviews");

  const confidence = Math.max(100 - (risks.length*15),10);
  let verdict = "🟢 SAFE";
  if(risks.length>0 && risks.length<2) verdict = "🟡 SAFE BUT LOW DATA";
  if(risks.length>=2) verdict = "⚠️ RISK";

  resultDiv.innerHTML = `
    <h2>🛡️ GigChecker Result</h2>
    <hr>
    <b>Site:</b> ${site} <br><hr>
    <b>Domain created:</b> ${createdDate} <br>
    <b>Domain age:</b> ${domainAge} <br>
    <b>Category:</b> General <br>
    <b>Connection:</b> ${connection} <br>
    <b>Nairaland mentions:</b> ${nairaland} <br>
    <b>Reddit mentions:</b> ${reddit} <br>
    <b>Trustpilot reviews:</b> ${trustpilot} <br>
    <hr>
    <b class="positive">Positive signals:</b>
    <ul class="positive">${positives.length ? positives.map(p=>`<li>${p}</li>`).join("") : "<li>None</li>"}</ul>
    <b class="risk">Risk factors:</b>
    <ul class="risk">${risks.length ? risks.map(r=>`<li>${r}</li>`).join("") : "<li>None detected</li>"}</ul>
    <hr>
    <b>${verdict}</b><br>
    <b>Safety confidence:</b> ${confidence}%<br>
    <b>Data coverage:</b> Medium<br>
    <hr>
    <div class="modal-footer">
      Built by <a href="https://www.instagram.com/ablbytes/" target="_blank">A.A.A</a> • Signal-based check using public data 🇳🇬<br>
      <span class="advice">Not financial advice. New scams may not yet appear in public data.</span>
    </div>
  `;
});

// Close modal
closeModal.addEventListener("click", () => {
  modalOverlay.classList.remove("active");
});

// Share icon
shareIcon.addEventListener("click", () => {
  const text = `Check this site with GigChecker 🇳🇬!`;
  if(navigator.share){
    navigator.share({ title:"GigChecker Result", text, url: window.location.href }).catch(console.error);
  } else {
    navigator.clipboard.writeText(window.location.href);
    alert("Link copied to clipboard!");
  }
});
